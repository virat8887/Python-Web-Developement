from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import UploadedFile
from .forms import FileUploadForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

@login_required
def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.save(commit=False)
            uploaded_file.user = request.user
            uploaded_file.save()
            return redirect('file_list')  # Redirect to a page displaying uploaded files
    else:
        form = FileUploadForm()
    return render(request, 'upload.html', {'form': form})


def home(request):
    return render(request, 'home.html')  # Replace 'home.html' with the name of your HTML template



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('some_redirect_url')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

