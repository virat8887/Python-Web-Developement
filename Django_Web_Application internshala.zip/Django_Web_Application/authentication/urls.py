from django.urls import path
from django.views.generic import TemplateView  # Import TemplateView for simplicity
from . import views


urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('upload/', views.upload_file, name='upload_file'),
    path('', views.home, name='home'),  # Replace 'home' with your desired URL pattern
    
]
from django.urls import path


urlpatterns = [
    # ... other URL patterns ...

    # Define the root URL pattern
    
]

